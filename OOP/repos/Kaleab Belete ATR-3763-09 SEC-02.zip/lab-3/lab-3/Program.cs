﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_3
{
    class Program
    {
        static int[][][] random_coin_flip()
        {
            // generates a random sized, randomly populated jagged array filled with 0s and 1s
            // 0 stands for heads and 1 stands for tails
            
            Random rnd = new Random();
            int size_i = rnd.Next(1, 6);
            int size_j = rnd.Next(1, 6);
            int size_k = rnd.Next(1, 6);

            int[][][] jagged_array = new int[size_i][][];
            for(int i = 0; i < size_i; i++)
            {
                int[][] jag = new int[size_j][];
                for (int j = 0; j < size_j; j++)
                {
                    int[] row = new int[size_k];
                    for(int k = 0; k < size_k; k++)
                    {
                        row[k] = rnd.Next(0, 2);
                    }
                    jag[j] = row;
                }
                jagged_array[i] = jag;
            }
            return jagged_array;
        }

        
        static void Question_a(int[][][] jagged_array) {
            int num_heads = 0;
            for(int i = 0; i < jagged_array.Length; i++)
            {
                for(int j = 0; j < jagged_array[i].Length; j++)
                {
                    for(int k = 0; k < jagged_array[i][j].Length; k++)
                    {
                        if(jagged_array[i][j][k] == 0)
                        {
                            num_heads = num_heads + 1;
                        }
                    }
                }
            }
            System.Console.WriteLine($"There are {num_heads} number of heads");
        }

        static void get_next_pos(int[][][] jagged_array, ref int i, ref int j, ref int k)
        {
            if (i == -1)
                return;
            if (k < jagged_array[i][j].Length - 1)
            {
                k++;
                return;
                
            }
            else if (j < jagged_array[i].Length - 1)
            {
                j++;
                k = 0;
                return;
            }
            else if (i < jagged_array.Length - 1)
            {
                i++;
                j = 0;
                k = 0;
                return;
            }
            else
            {
                i = -1;
                j = -1;
                k = -1;
                return;
            }
        }

        static void Question_b(int[][][] jagged_array)
        {
            int num_consecutive_heads = 0, consecutive_count = 0;
            int i = 0, j = 0, k = 0;
            bool prev_head = false;
            while(true)
            {
                if (i == -1)
                    break;
                int elem = jagged_array[i][j][k];
                if(elem == 0 && prev_head == false)
                {
                    prev_head = true;
                    consecutive_count++;
                }
                else if(elem == 0)
                {
                    // check that the next element is not a head
                    get_next_pos(jagged_array, ref i, ref j, ref k);
                    if (i != -1 && jagged_array[i][j][k] != 0 && consecutive_count == 1)
                    {
                        num_consecutive_heads++;
                        //reset indices
                        prev_head = false;
                        consecutive_count = 0;
                    }
                    else
                        consecutive_count++;
                }
                else
                {
                    // reset indices
                    prev_head = false;
                    consecutive_count = 0;
                }
                //increment position
                get_next_pos(jagged_array, ref i, ref j, ref k);
                
            }
            System.Console.WriteLine($"There are {num_consecutive_heads} consecutive heads");
        }

        static void Question_c(int[][][] jagged_array)
        {
            int num_consecutive = 0;
            int i = 0, j = 0, k = 0;
            bool prev_tail = false;
            while(true)
            {
                if (i == -1)
                    break;
                int elem = jagged_array[i][j][k];

                if (elem == 1)
                {
                    // get the next position
                    int i1 = i, j1 = j, k1 = k;
                    get_next_pos(jagged_array, ref i1, ref j1, ref k1);
                    if (i1 == -1) break;
                    int elem_1 = jagged_array[i1][j1][k1];
                    // get the next position
                    get_next_pos(jagged_array, ref i1, ref j1, ref k1);
                    if (i1 == -1) break;
                    int elem_2 = jagged_array[i1][j1][k1];
                    // get the next position
                    get_next_pos(jagged_array, ref i1, ref j1, ref k1);
                    if (i1 == -1) break;
                    int elem_3 = jagged_array[i1][j1][k1];
                    // get the following position
                    get_next_pos(jagged_array, ref i1, ref j1, ref k1);
                    int elem_4 = -1;
                    if (i1 != -1)
                        elem_4 = jagged_array[i1][j1][k1];
                    // now check if elem_1 is 0, elem_2 = 1, elem_3 = 1
                    if (elem_1 == 1 && elem_2 == 0 && elem_3 == 0 && prev_tail == false && elem_4 != 0)
                    {
                        num_consecutive++;
                        // update i, j and k
                        i = i1; j = j1; k = k1;
                        get_next_pos(jagged_array, ref i, ref j, ref k);
                        prev_tail = false;
                        continue;
                    }
                    else
                        prev_tail = true;
                }
                else
                    prev_tail = false;
                // upgrade i, j and k
                get_next_pos(jagged_array, ref i, ref j, ref k);
            }
            System.Console.WriteLine($"There are {num_consecutive} consecutive combination of two tails and two heads");
        }

        static int[,,] generate_random_array()
        {
            Random rnd = new Random();
            int size_1 = rnd.Next(1, 10);
            int size_2 = rnd.Next(1, 10);
            int size_3 = rnd.Next(1, 10);

            int[,,] array = new int[size_1,size_2,size_3];
            for(int i = 0; i < array.GetLength(0); i++)
            {
                for(int j = 0; j < array.GetLength(1); j++)
                {
                    for(int k = 0; k < array.GetLength(2); k++)
                    {
                        int val = rnd.Next(1, 300);
                        array[i, j, k] = val;
                    }
                }
            }
            return array;
        }
        static void Question_2(int[,,] array)
        {
            int sum = 0;
            for(int i = 0; i < array.GetLength(0); i++)
            {
                for(int j = 0; j < array.GetLength(1); j++)
                {
                    for(int k = 0; k < array.GetLength(2); k++)
                    {
                        int elem = array[i, j, k];
                        if (elem % 3 == 0)
                            sum += elem;
                    }
                }
            }
            System.Console.WriteLine($"The sum of all array elements divisible by three equals {sum}");
        }
        static void Main(string[] args)
        {
            int[][][] jagged_array = random_coin_flip();
            // print the coins
            for(int i = 0; i < jagged_array.Length; i++)
            {
                for(int j = 0; j < jagged_array[i].Length; j++)
                {
                    for(int k = 0; k < jagged_array[i][j].Length; k++)
                    {
                        System.Console.Write(jagged_array[i][j][k] == 0 ? "h" : "t");
                    }
                }
            }
            System.Console.WriteLine();
            Question_a(jagged_array);
            Question_b(jagged_array);
            Question_c(jagged_array);
            System.Console.WriteLine("\n The elements of the randomly generated array are:");
            int[,,] array = generate_random_array();
            for(int i = 0; i < array.GetLength(0); i++)
            {
                for(int j = 0; j < array.GetLength(1); j++)
                {
                    for(int k = 0; k < array.GetLength(2); k++)
                    {
                        System.Console.Write($"{array[i, j, k]}, ");
                    }
                }
            }
            System.Console.WriteLine();
            Question_2(array);
        }
    }
}
