1) The random_coin_flip() function requires N * M * L space to hold the multi-dimensional jagged array of dynamically created size. Since it 
   uses three for loops to iterate through the array, it has a time complexity of O(N*M*L).
2) Likewise Question_A() requires a space of N * M * L to hold the multi-dimensional jagged array. It also iterates through every row, every column
   and every value to find the heads so it has an average case time complexity of O(N*M*L).
3) get_next_pos() also requires N*M*L space to hold the array. But it has a time complexity of O(1).
4) Question_B() requires N*M*L space. It has a time complexity of O(N*M*L).
5) Question_C() requires N*M*L space. It also has a time complexity of O(N*M*L).
6) generate_random_arrays() has a space complexity of O(N*M*L) and a time complexity of O(N*M*L).
7) Question_2() requires N*M*L space and O(N*M*L) time complexity